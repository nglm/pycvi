"""
Some datasets for examples and tests.
"""

