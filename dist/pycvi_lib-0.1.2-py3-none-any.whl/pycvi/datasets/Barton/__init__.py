"""
Datasets aggregated by Thomas Barton, on his GitHub repository. [1]_

.. [1]  T. Barton, “Clustering benchmarks.”
  ”https://github.com/deric/clusteringbenchmark”, 2015. [Online;
  accessed 06-December-2023].
"""