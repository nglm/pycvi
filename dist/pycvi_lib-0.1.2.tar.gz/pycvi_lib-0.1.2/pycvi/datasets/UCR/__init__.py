"""
Datasets from the UCR Time Series Classification Archive. [UCR]_


.. [UCR] H. A. Dau, E. Keogh, K. Kamgar, C.-C. M. Yeh, Y. Zhu, S.
  Gharghabi, C. A. Ratanamahatana, Yanping, B. Hu, N. Begum, A. Bagnall,
  A. Mueen, G. Batista, and Hexagon-ML, “The ucr time series
  classification archive,” October 2018.
  https://www.cs.ucr.edu/~eamonn/time_series_data_2018/
"""